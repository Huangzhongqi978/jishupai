import datetime
import json
import uuid

from django.http import JsonResponse
from Content.models import User, Question


def question_list_service(request):
    data = json.load(request)
    _name = data['name']
    _pageSize = data['pageSize']
    _currentPage = data['currentPage']
    list = Question.objects.filter(deleted=0)
    # if _name is not None and _name != '':
    #     list = Course.objects.filter(deleted=0, name__contains=_name)
    _list = []
    for item in list:
        rest = {}
        rest['id'] = item.id
        rest['uid'] = item.uid
        rest['description'] = item.description
        rest['content'] = item.content
        rest['name'] = item.name
        if item.createDate is not None:
            rest['createDate'] = item.createDate.strftime('%Y-%m-%d')
        _list.append(rest)
    page = {
        "pageSize": _pageSize,
        "total": len(_list),
        "currentPage": _currentPage
    }
    if _pageSize < len(_list):
        if _pageSize * _currentPage > len(_list):
            _start = (_currentPage - 1) * _pageSize
            _list = _list[_start: len(_list)]
        if _pageSize * _currentPage <= len(_list):
            _start = (_currentPage - 1) * _pageSize
            _end = _currentPage * _pageSize
            _list = _list[_start: _end]
    data1 = {
        "success": "true",
        "message": "操作成功",
        "returnCode": "200",
        "returnData": {
            "list": _list,
            "page": page,
        }
    }
    return JsonResponse(data1)


def question_add_service(request):
    data = json.load(request)
    _name = data.get('name', '')
    _description = data.get('description', '')
    Question.objects.create(
        uid=uuid.uuid4(),
        name=data.get('name', ''),
        description=data.get('description', ''),
        content=data.get('content', ''),
    )
    data1 = {
        "success": "true",
        "message": "操作成功",
        "returnCode": "200",
        "returnData": data
    }
    return JsonResponse(data1)


def question_modify_service(request):
    data = json.load(request)
    _id = data['id']
    rest = Question.objects.filter(id=_id, deleted=0).first()
    if rest is None:
        data1 = {
            "success": "false",
            "message": "查询不存在",
            "returnCode": "500",
            "returnData": data
        }
        return JsonResponse(data1)
    Question.objects.filter(id=_id).update(
        name=data.get('name', ''),
        amount=data.get('amount', 0),
        description=data.get('description', ''),
        content=data.get('content', ''),
    )
    data1 = {
        "success": "true",
        "message": "操作成功",
        "returnCode": "200",
        "returnData": data
    }
    return JsonResponse(data1)


def question_delete_service(request):
    data = json.load(request)
    _id = data['id']
    rest = Question.objects.filter(id=_id, deleted=0).first()
    if rest is None:
        data1 = {
            "success": "false",
            "message": "查询不存在",
            "returnCode": "500",
            "returnData": data
        }
        return JsonResponse(data1)
    Question.objects.filter(id=_id).update(
        deleted=1,
    )
    data1 = {
        "success": "true",
        "message": "操作成功",
        "returnCode": "200",
        "returnData": data
    }
    return JsonResponse(data1)


def question_detail_service(request):
    data = json.load(request)
    _id = data['id']
    item = Question.objects.filter(id=_id, deleted=0).first()
    if item is None:
        data1 = {
            "success": "false",
            "message": "查询不存在",
            "returnCode": "500",
            "returnData": data
        }
        return JsonResponse(data1)
    rest = {'id': item.id, 'uid': item.uid, 'name': item.name, 'user': item.user, 'image': item.image,
            'description': item.description}
    if item.createDate is not None:
        rest['createDate'] = item.createDate.strftime('%Y-%m-%d')
    data1 = {
        "success": "true",
        "message": "操作成功",
        "returnCode": "200",
        "returnData": {
            "rest": rest,
        }
    }
    return JsonResponse(data1)
