from py2neo import Graph, Node, Relationship, NodeMatcher


class MarriageLawGraph:
    def __init__(self):
        self.graph = Graph("bolt://localhost:7687", auth=("neo4j", "7508929hzq"))
        self.matcher = NodeMatcher(self.graph)

    def clear_database(self):
        """清空现有数据库（谨慎使用）"""
        self.graph.delete_all()
        print("数据库已清空")

    def create_node(self, label, name, desc):
        """创建节点并返回节点对象"""
        if not self.matcher.match(label, name=name).first():
            node = Node(label, name=name, desc=desc)
            self.graph.create(node)
            print(f"创建节点: {name}")
            return node
        else:
            print(f"节点已存在: {name}")
            return self.matcher.match(label, name=name).first()

    def add_relation(self, parent_name, child_name, relation_type="包含"):
        """通过节点名称建立关系"""
        parent = self.matcher.match("婚姻法图谱", name=parent_name).first()
        child = self.matcher.match("婚姻法图谱", name=child_name).first()

        if not parent:
            raise ValueError(f"父节点不存在: {parent_name}")
        if not child:
            raise ValueError(f"子节点不存在: {child_name}")

        relation = Relationship(parent, relation_type, child)
        self.graph.create(relation)
        print(f"建立关系: {parent_name} -> {child_name}")


def build_marriage_law_graph():
    builder = MarriageLawGraph()

    # 1. 创建根节点
    root = builder.create_node("婚姻法图谱", "婚姻法图谱", "婚姻法知识图谱总节点")

    # 2. 构建结婚相关节点
    marriage = builder.create_node("婚姻法图谱", "结婚", "结婚相关法律规定")
    builder.add_relation("婚姻法图谱", "结婚")

    marriage_nodes = [
        ("结婚年龄", "男不得早于二十二周岁，女不得早于二十周岁。晚婚晚育应予鼓励"),
        ("禁止结婚", "（一）直系血亲和三代以内的旁系血亲；（二）患有医学上认为不应当结婚的疾病"),
        ("结婚登记", "要求结婚的男女双方必须亲自到婚姻登记机关进行结婚登记"),
        ("婚姻无效", "（一）重婚的；（二）有禁止结婚的亲属关系的；（三）婚前患病未愈的；（四）未到法定婚龄的"),
        ("胁迫结婚", "受胁迫方可请求撤销婚姻，需在结婚登记之日起一年内提出"),
        ("婚姻撤销", "撤销后的财产和子女抚养处理规定")
    ]

    for name, desc in marriage_nodes:
        builder.create_node("婚姻法图谱", name, desc)
        builder.add_relation("结婚", name)

    # 3. 构建家庭关系节点
    family = builder.create_node("婚姻法图谱", "家庭关系", "家庭成员间的权利义务")
    builder.add_relation("婚姻法图谱", "家庭关系")

    family_nodes = [
        ("夫妻共同财产", "工资、奖金、生产经营收益等属于共同财产"),
        ("夫妻一方财产", "婚前财产、人身损害赔偿等属于个人财产"),
        ("抚养子女", "父母对子女的抚养义务规定"),
        ("赡养父母", "子女对父母的赡养义务规定"),
        ("继承权", "夫妻和父母子女间的继承权利")
    ]

    for name, desc in family_nodes:
        builder.create_node("婚姻法图谱", name, desc)
        builder.add_relation("家庭关系", name)

    # 4. 构建离婚相关节点
    divorce = builder.create_node("婚姻法图谱", "离婚", "离婚相关法律规定")
    builder.add_relation("婚姻法图谱", "离婚")

    divorce_nodes = [
        ("自愿离婚", "双方自愿离婚的程序和要求"),
        ("离婚条件", "感情破裂的具体情形认定"),
        ("子女抚养", "离婚后子女抚养安排原则"),
        ("财产分割", "共同财产分割原则"),
        ("离婚赔偿", "无过错方请求赔偿的情形")
    ]

    for name, desc in divorce_nodes:
        builder.create_node("婚姻法图谱", name, desc)
        builder.add_relation("离婚", name)

    # 5. 构建法律救助节点
    legal_aid = builder.create_node("婚姻法图谱", "法律救助", "婚姻家庭法律救济途径")
    builder.add_relation("婚姻法图谱", "法律救助")

    aid_nodes = [
        ("家庭暴力", "对家庭暴力的法律干预措施"),
        ("遗弃行为", "对遗弃家庭成员的处罚规定"),
        ("强制执行", "对拒不执行抚养费等判决的强制措施")
    ]

    for name, desc in aid_nodes:
        builder.create_node("婚姻法图谱", name, desc)
        builder.add_relation("法律救助", name)


if __name__ == '__main__':
    # #首次运行可先清空数据库（慎用）
    # MarriageLawGraph().clear_database()

    # 构建知识图谱
    build_marriage_law_graph()
    print("婚姻法知识图谱构建完成！")