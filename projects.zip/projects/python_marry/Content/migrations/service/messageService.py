import datetime
import json
import uuid

from django.http import JsonResponse

from Content.migrations.service import userService
from Content.models import User, Message, Question


def message_list_service(request):
    data = json.load(request)
    _pageSize = data['pageSize']
    _currentPage = data['currentPage']
    _content = data.get('content', '')
    _user = userService.getCurrentUser(request)
    list = Message.objects.filter(deleted=0)
    if _user.role == '1':
        list = Message.objects.filter(deleted=0, user=_user.uid)
    _list = []
    _status_dict = {
        "0": "未回复",
        "1": "已回复"
    }
    userList = User.objects.filter(deleted=0, role='1')
    _user_list = []
    _user_dict = {}
    _user_image_dict = {}
    for item in userList:
        rest = {}
        rest['uid'] = item.uid
        rest['name'] = item.name
        _user_list.append(rest)
        _user_dict[item.uid] = item.name
        _user_image_dict[item.uid] = item.image
    for item in list:
        rest = {}
        rest['id'] = item.id
        rest['uid'] = item.uid
        rest['name'] = item.name
        rest['description'] = item.description
        rest['content'] = item.content
        rest['status'] = item.status
        if item.status is not None and item.status != '':
            rest['statusName'] = _status_dict.get(item.status, '')
        rest['user'] = item.user
        if item.user is not None and item.user != '':
            rest['userName'] = _user_dict.get(item.user, '')
            rest['userImage'] = _user_image_dict.get(item.user, '')
        if item.createDate is not None:
            rest['createDate'] = item.createDate.strftime('%Y-%m-%d')
        _list.append(rest)
    page = {
        "pageSize": _pageSize,
        "total": len(_list),
        "currentPage": _currentPage
    }
    if _pageSize < len(_list):
        if _pageSize * _currentPage > len(_list):
            _start = (_currentPage - 1) * _pageSize
            _list = _list[_start: len(_list)]
        if _pageSize * _currentPage <= len(_list):
            _start = (_currentPage - 1) * _pageSize
            _end = _currentPage * _pageSize
            _list = _list[_start: _end]
    data1 = {
        "success": "true",
        "message": "操作成功",
        "returnCode": "200",
        "returnData": {
            "list": _list,
            "page": page,
            "userList": _user_list,
        }
    }
    return JsonResponse(data1)


def message_add_service(request):
    data = json.load(request)
    _status = data.get('status', '')
    _name = data.get('name', '')
    _user = userService.getCurrentUser(request)
    _person = Message.objects.filter(user=_user.uid, deleted=0).first()
    _question_list = Question.objects.filter(deleted=0)
    _description = ""
    _content = ""
    _question_dict = {}
    for item in _question_list:
        if item.name in _name:
            _description = item.description
            _content = item.content
            _status = "1"
    if _description == "":
        _description = getMaxPattern(_name, _question_list)
        _status = "1"
    Message.objects.create(
        uid=uuid.uuid4(),
        name=data.get('name', ''),
        status=_status,
        description=_description,
        content=_content,
        user=_user.uid,
    )
    data1 = {
        "success": "true",
        "message": "操作成功",
        "returnCode": "200",
        "returnData": data
    }
    return JsonResponse(data1)


def getMaxPattern(_str, _question_list):
    _description = ""
    _score = 0
    for item in _question_list:
        score = calculate(_str, item.name)
        if score > _score:
            _score = score
            _description = item.description
    return _description


def calculate(_str, pattern):
    score = 0
    for i in range(0, len(_str)):
        if _str[i] in pattern:
            score = score + 1
    return score


def message_modify_service(request):
    data = json.load(request)
    _uid = data['uid']
    rest = Message.objects.filter(uid=_uid, deleted=0).first()
    if rest is None:
        data1 = {
            "success": "false",
            "message": "查询不存在",
            "returnCode": "500",
            "returnData": data
        }
        return JsonResponse(data1)
    Message.objects.filter(uid=_uid).update(
        content=data.get('content', ''),
        user=data.get('user', ''),
        period=data.get('period', '0'),
        contentDate=data.get('contentDate', datetime.datetime.now()),
        status=data.get('status', '0'),
    )
    data1 = {
        "success": "true",
        "message": "操作成功",
        "returnCode": "200",
        "returnData": data
    }
    return JsonResponse(data1)


def message_delete_service(request):
    data = json.load(request)
    _uid = data['uid']
    rest = Message.objects.filter(uid=_uid, deleted=0).first()
    if rest is None:
        data1 = {
            "success": "false",
            "message": "查询不存在",
            "returnCode": "500",
            "returnData": data
        }
        return JsonResponse(data1)
    Message.objects.filter(uid=_uid).update(
        deleted=1,
    )
    data1 = {
        "success": "true",
        "message": "操作成功",
        "returnCode": "200",
        "returnData": data
    }
    return JsonResponse(data1)


def detail_service(request):
    data = json.load(request)
    _uid = data['uid']
    item = Message.objects.filter(uid=_uid, deleted=0).first()
    if item is None:
        data1 = {
            "success": "false",
            "message": "查询不存在",
            "returnCode": "500",
            "returnData": data
        }
        return JsonResponse(data1)
    _period_dict = {
        "0": "08:00-10:00",
        "1": "10:00-12:00",
        "2": "13:00-15:00",
        "3": "15:00-17:00",
    }
    _status_dict = {
        "0": "可预约",
        "1": "已预约"
    }
    content = Message.objects.filter(deleted=0, uid=item.content).first()
    _content = {'id': content.id, 'uid': content.uid, 'name': content.name, 'classification': content.classification,
                'amount': content.amount, 'price': content.price, 'description': content.description,
                'image': content.image}
    user = User.objects.filter(deleted=0, uid=item.user).first()
    _user = {'id': user.id, 'uid': user.uid, 'name': user.name, 'username': user.username, 'password': user.password,
             'gender': user.gender, 'age': user.age, 'mobile': user.mobile, 'email': user.email, 'image': user.image}
    rest = {'id': item.id, 'uid': item.uid, 'period': item.period}
    if item.period is not None and item.period != '':
        rest['periodName'] = _period_dict.get(item.period, '')
    rest['content'] = item.content
    rest['status'] = item.status
    if item.status is not None and item.status != '':
        rest['statusName'] = _status_dict.get(item.status, '')
    rest['user'] = item.user
    rest['contentDate'] = item.contentDate
    if item.contentDate is not None:
        rest['contentDateName'] = item.contentDate.strftime('%Y-%m-%d')
    if item.createDate is not None:
        rest['createDate'] = item.createDate.strftime('%Y-%m-%d')
    data1 = {
        "success": "true",
        "message": "操作成功",
        "returnCode": "200",
        "returnData": {
            "user": _user,
            "product": rest,
            "content": _content
        }
    }
    return JsonResponse(data1)
