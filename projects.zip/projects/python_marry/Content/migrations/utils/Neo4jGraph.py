import json
import os

from py2neo import Graph, Node

from Content.migrations.service.marryService import create_node


class MedicalGraph:
    def __init__(self):
        cur_dir = '/'.join(os.path.abspath(__file__).split('/')[:-1])
        self.data_path = os.path.join(cur_dir, 'data/medical.json')
        self.g = Graph("bolt://localhost:7687", auth=("neo4j", "7508929hzq"))


if __name__ == '__main__':
    # create_node()
    str = "多大年龄结婚比较合适"
    pattern = "结婚年龄"
    score = 0
    for i in range(0, 10):
        print(str[i])
        if str[i] in pattern:
            score = score + 1
    print(score)
