from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods

from Content.COSUploadUtils import upload_service
from Content.migrations.service import userService, classificationService, contentService, messageService, \
    noticeService, questionService, imageService


@csrf_exempt
def image_upload(request):
    return upload_service(request)


@csrf_exempt
@require_http_methods(["POST"])
def image_upload_base64(request):
    return imageService.image_upload_base64(request)


# Create your views here.
@csrf_exempt
def validate(request):
    return userService.validate_service(request)


@csrf_exempt
def register(request):
    return userService.register_service(request)


@csrf_exempt
def user_list(request):
    return userService.user_list_service(request)


@csrf_exempt
def user_add(request):
    return userService.user_add_service(request)


@csrf_exempt
def user_modify(request):
    return userService.user_modify_service(request)


@csrf_exempt
def user_delete(request):
    return userService.user_delete_service(request)


def user_detail(request):
    return userService.user_detail_service(request)


@csrf_exempt
def user_currentUser(request):
    return userService.user_currentUser_service(request)


@csrf_exempt
def classification_list(request):
    return classificationService.classification_list_service(request)


@csrf_exempt
def classification_add(request):
    return classificationService.classification_add_service(request)


@csrf_exempt
def classification_modify(request):
    return classificationService.classification_modify_service(request)


@csrf_exempt
def classification_delete(request):
    return classificationService.classification_delete_service(request)


def classification_detail(request):
    return classificationService.classification_detail_service(request)


@csrf_exempt
def content_list(request):
    return contentService.content_list_service(request)


@csrf_exempt
def content_add(request):
    return contentService.content_add_service(request)


@csrf_exempt
def content_modify(request):
    return contentService.content_modify_service(request)


@csrf_exempt
def content_delete(request):
    return contentService.content_delete_service(request)


def content_detail(request):
    return contentService.content_detail_service(request)


@csrf_exempt
def question_list(request):
    return questionService.question_list_service(request)


@csrf_exempt
def question_add(request):
    return questionService.question_add_service(request)


@csrf_exempt
def question_modify(request):
    return questionService.question_modify_service(request)


@csrf_exempt
def question_delete(request):
    return questionService.question_delete_service(request)


@csrf_exempt
def question_detail(request):
    return questionService.question_detail_service(request)


@csrf_exempt
def notice_list(request):
    return noticeService.notice_list_service(request)


@csrf_exempt
def notice_add(request):
    return noticeService.notice_add_service(request)


@csrf_exempt
def notice_modify(request):
    return noticeService.notice_modify_service(request)


@csrf_exempt
def notice_delete(request):
    return noticeService.notice_delete_service(request)


@csrf_exempt
def notice_detail(request):
    return noticeService.notice_detail_service(request)


@csrf_exempt
def message_list(request):
    return messageService.message_list_service(request)


@csrf_exempt
def message_add(request):
    return messageService.message_add_service(request)


@csrf_exempt
def message_modify(request):
    return messageService.message_modify_service(request)


@csrf_exempt
def message_delete(request):
    return messageService.message_delete_service(request)


@csrf_exempt
def message_detail(request):
    return messageService.schema_detail_service(request)
