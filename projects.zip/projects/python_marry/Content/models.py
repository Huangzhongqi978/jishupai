import uuid
from django.db import models


class User(models.Model):
    uid = models.CharField(max_length=64, default=uuid.uuid4())
    name = models.CharField(max_length=64)
    username = models.CharField(max_length=64)
    password = models.CharField(max_length=64)
    gender = models.CharField(max_length=64)
    role = models.CharField(max_length=64)
    image = models.CharField(max_length=1024)
    age = models.IntegerField()
    mobile = models.CharField(max_length=64)
    email = models.CharField(max_length=64)
    description = models.CharField(max_length=1024)
    deleted = models.IntegerField(default=0)
    createDate = models.DateField(auto_now_add=True)
    updateDate = models.DateField(auto_now_add=True)
    operator = models.CharField(max_length=64)

    class Meta:
        ordering = ['createDate']
        db_table = 'python_marry_user'


class Content(models.Model):
    uid = models.CharField(max_length=64, default=uuid.uuid4())
    name = models.CharField(max_length=64)
    classification = models.CharField(max_length=64)
    image = models.CharField(max_length=1024)
    description = models.CharField(max_length=1024)
    content = models.CharField(max_length=1024)
    deleted = models.IntegerField(default=0)
    createDate = models.DateField(auto_now_add=True)
    updateDate = models.DateField(auto_now_add=True)
    operator = models.CharField(max_length=64)

    class Meta:
        ordering = ['createDate']
        db_table = 'python_marry_content'


class Classification(models.Model):
    uid = models.CharField(max_length=64, default=uuid.uuid4())
    name = models.CharField(max_length=64)
    content = models.CharField(max_length=64)
    image = models.CharField(max_length=1024)
    description = models.CharField(max_length=1024)
    deleted = models.IntegerField(default=0)
    createDate = models.DateField(auto_now_add=True)
    updateDate = models.DateField(auto_now_add=True)
    operator = models.CharField(max_length=64)

    class Meta:
        db_table = 'python_marry_classification'

class Question(models.Model):
    id = models.AutoField(primary_key=True)
    uid = models.CharField(max_length=64, default=uuid.uuid4())
    name = models.CharField(max_length=64)
    description = models.CharField(max_length=1024)
    content = models.CharField(max_length=1024)
    amount = models.IntegerField(default=0)
    deleted = models.IntegerField(default=0)
    createDate = models.DateField(auto_now_add=True)
    updateDate = models.DateField(auto_now_add=True)
    operator = models.CharField(max_length=64)

    class Meta:
        ordering = ['createDate']
        db_table = 'python_marry_question'


class Notice(models.Model):
    uid = models.CharField(max_length=64, default=uuid.uuid4())
    name = models.CharField(max_length=64)
    content = models.CharField(max_length=64)
    image = models.CharField(max_length=1024)
    description = models.CharField(max_length=1024)
    deleted = models.IntegerField(default=0)
    createDate = models.DateField(auto_now_add=True)
    updateDate = models.DateField(auto_now_add=True)
    operator = models.CharField(max_length=64)

    class Meta:
        db_table = 'python_marry_notice'

class Message(models.Model):
    uid = models.CharField(max_length=64, default=uuid.uuid4())
    user = models.CharField(max_length=64)
    name = models.CharField(max_length=64)
    description = models.CharField(max_length=1024)
    content = models.CharField(max_length=1024)
    status = models.CharField(max_length=64)
    deleted = models.IntegerField(default=0)
    createDate = models.DateField(auto_now_add=True)
    updateDate = models.DateField(auto_now_add=True)
    operator = models.CharField(max_length=64)

    class Meta:
        ordering = ['createDate']
        db_table = 'python_marry_message'


