module.exports = {
	plugins: {
		autoprefixer: {}
	}
};
