import Layout from "@/layouts/index";
/**
 * @description: default layout
 */
export const LayoutIndex = () => <Layout />;
