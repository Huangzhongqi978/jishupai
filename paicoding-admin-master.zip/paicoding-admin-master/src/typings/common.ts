export interface MapItem {
	[key: string]: any;
}
