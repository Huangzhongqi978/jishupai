# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### 0.0.1 (2022-09-19)

### Features

- 🚀 项目初始化（今天的 🧱 格外烫手）

### Bug Fixes

- 🧩 密密麻麻
